module InquiriesHelper
end
