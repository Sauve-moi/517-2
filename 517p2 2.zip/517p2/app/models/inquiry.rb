class Inquiry < ApplicationRecord
end
