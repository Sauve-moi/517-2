class PotentialBuyers < ApplicationRecord
end