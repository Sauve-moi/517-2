module SearchesHelper
end
